import React from 'react';
import FacebookLogin from 'react-facebook-login';
//import TiSocialFacebookCircular from 'react-icons/lib/ti/social-facebook-circular';
import { useNavigate } from 'react-router-dom';

const SocialLogin = () => {
    const navigate = useNavigate();

    // test facebook
    const componentClicked = () => {
        navigate('/sign-in/facebook-callback');
        // redirection 是否可以进一步抽象
        console.log("facebook button clicked");
    }
    const responseFacebook = (response) => {
        console.log(response);
    }
    return (
        <div>
            <FacebookLogin
                appId="206755055457088"
                autoLoad={true}
                fields="name,email,picture"
                onClick={componentClicked}
                callback={responseFacebook}
                // icon={<TiSocialFacebookCircular />}
            />
        </div>
    )
}

export default SocialLogin;
