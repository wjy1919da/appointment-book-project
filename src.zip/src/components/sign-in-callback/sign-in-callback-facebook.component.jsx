import React, { useEffect } from 'react';
import { useLocation } from 'react-router-dom';

const SignInCallbackFacebook = () => {
    const location = useLocation();

    useEffect(() => {
        // 在这里处理从 Facebook 返回的数据，如访问令牌和用户信息
        // 你也可以在这里调用后端 API
        console.log("location: ",location);
        const searchParams = new URLSearchParams(location.search);
        // 提取 access_token 参数
        const accessToken = searchParams.get('access_token');
        if (accessToken) {
            // 在这里使用 accessToken 执行其他操作，例如获取用户信息
            console.log('Access Token:', accessToken);
        } else {
            // 处理错误情况，例如提取错误信息
            const error = searchParams.get('error');
            const errorDescription = searchParams.get('error_description');
            console.log('Error:', error);
            console.log('Error Description:', errorDescription);
        }

    }, [location]);

    return (
        <div>

        </div>
    );
};

export default SignInCallbackFacebook;
