import { useNavigate } from 'react-router-dom';
import './home-button.styles.scss';
//button with link
// props: link title, link href
const HomeButton = (props) => {
    const navigate = useNavigate();
    const handleClick = () => {
        console.log(props.href);
        navigate(props.href);
    }
    return <button className='home-button' onClick={handleClick}>{props.title}</button>;
};

export default HomeButton;


