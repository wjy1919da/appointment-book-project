import './doctor.styles.scss'
import React, { useState } from 'react';
import axios from 'axios';
import HomeButton from '../../components/home-button/home-button.component';
const Doctor = () => {
    const [doctorOrTreatment, setDoctorOrTreatment] = useState('');
    const [city, setCity] = useState('');
    const handleSearch = async () => {
        try {
          const response = await axios.get('http://your-backend-url.com/api/search', {
            params: {
              doctorOrTreatment,
              city
            }
          });
          console.log(response.data);
          // 处理你的响应数据
        } catch (error) {
          console.error('Error during search:', error);
        }
      };
    return (
       <div>
             <input
                type="text"
                placeholder="Doctor or Treatment"
                value={doctorOrTreatment}
                onChange={(e) => setDoctorOrTreatment(e.target.value)}
            />
            <input
                type="text"
                placeholder="City"
                value={city}
                onChange={(e) => setCity(e.target.value)}
            />
            <HomeButton title="search" onClick={handleSearch} />
       </div> 
        
        
    );

};
export default Doctor;