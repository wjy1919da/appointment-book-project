const SubProcedureReference = () => {
    const reference = [
        "https://www.runoob.com/html/html-lists.html",
        "https://www.runoob.com/html/html-lists.html",
        "https://www.example.com/xz2c5pd",
        "https://www.example.com/qw7e3rf",
        "https://www.example.com/vt1n6ml"
    ];
    const referenceList = reference.map((ref, index) => {
        return(
            <li key={index}>
                <a href={ref} >{ref}</a>
            </li>
        );
    });

    return (
        <div>
            <ul>
               {referenceList}
            </ul>
        </div>
    );   
};

export default SubProcedureReference;
