import './sub-procedure-form.styles.scss'

const SubProcedureForm = (props) => {
  //const { data } = props;
  //console.log("data in sub procedure-form", data);
  const header = [{}, {
		"name": "Option 1"
	}, {
		"name": "Option 2"
	}, {
		"name": "Option 3"
	}];
  const body = [{
    "name": "Lorem ipsum dolor sit amet consectetur",
    "value": ["Lorem ipsum", "Lorem ipsum", "Lorem ipsum"]
  },
  {
    "name": "Lorem ipsum dolor sit amet consectetur",
    "value": ["Lorem ipsum", "Lorem ipsum", "Lorem ipsum"]
  },
  {
    "name": "Lorem ipsum dolor sit amet consectetur",
    "value": ["Lorem ipsum", "Lorem ipsum", "Lorem ipsum"]
  },
  {
    "name": "Lorem ipsum dolor sit amet consectetur",
    "value": ["Lorem ipsum", "Lorem ipsum", "Lorem ipsum"]
  }
 ];
  
 return (
  <div className='sub-procedure-form'>
      <table className="table table-striped" style={{ width: '800px', height: '60px' }}>
          <thead>
              <tr>
                  {header.map((item, index) => (
                      <th key={index} style={{ width: '25%', height: '60px', textAlign: 'center', verticalAlign: 'middle' }}>
                          {item.name}
                      </th>
                  ))}
              </tr>
          </thead>
          <tbody>
              {body.map((item, index) => (
                  <tr key={index}>
                      <td style={{ width: '25%', height: '60px', textAlign: 'center', verticalAlign: 'middle' }}>
                          {item.name}
                      </td>
                      {item.value.map((value, valueIndex) => (
                          <td key={valueIndex} style={{ width: '25%', height: '60px', textAlign: 'center', verticalAlign: 'middle' }}>
                              {value}
                          </td>
                      ))}
                  </tr>
              ))}
          </tbody>
      </table>
  </div>
);
   
}
export default SubProcedureForm;