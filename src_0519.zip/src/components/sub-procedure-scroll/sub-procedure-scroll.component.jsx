import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";
import './sub-procedure-scroll.styles.scss'
import SubProcedureScrollCard from './sub-procedure-scroll-card/sub-procedure-scroll-card.component';
const SubProcedureScroll = () => {
  const responsive = {
    superLargeDesktop: {
      // the naming can be any, depends on you.
      breakpoint: { max: 4000, min: 1000 },
      items: 2
    },
    desktop: {
      breakpoint: { max: 1000, min: 500 },
      items: 2
    },
    tablet: {
      breakpoint: { max: 1024, min: 464 },
      items: 2
    },
    mobile: {
      breakpoint: { max: 464, min: 0 },
      items: 1
    }
  };
  const data = [
      {
        "before":"facial_injection_before_group1.png",
        "after":"facial_injection_after_group1.png"
      },
      {
        "before":"facial_injection_before_group2.png",
        "after":"facial_injection_after_group2.png"
      },
      {
        "before":"facial_injection_before_group1.png",
        "after":"facial_injection_after_group1.png"
      },
      {
        "before":"facial_injection_before_group2.png",
        "after":"facial_injection_after_group2.png"
      },
      {
        "before":"facial_injection_before_group1.png",
        "after":"facial_injection_after_group1.png"
      }
  ];
  let cards = data.map((item, index) => (
     <SubProcedureScrollCard before={item.before} after={item.after} />
  ));

  return (
      <div>
         <Carousel responsive={responsive}>
            {cards}      
        </Carousel>
      </div>
  )
};
export default SubProcedureScroll;