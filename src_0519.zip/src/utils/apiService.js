import axios from 'axios';
const base = {
  baseUrl: 'https://run.mocky.io/v3/0d8cb432-4ff4-4c04-879f-65f2e4d7f870',
}

export const search = async (params) => {
  const response = await axios.get(base.baseUrl, { params: params });
  return response.data;
};

export const getProcedures = async (params) => { 
    const response = await axios.get(base.baseUrl, { params: params });
    return response.data;
}

