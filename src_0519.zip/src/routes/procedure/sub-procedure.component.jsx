import StyledButtonV3 from '../../components/styled-button-v3/styled-button-v3.component';
import Footer from "../../components/footer/footer.component";
import { Link} from 'react-router-dom';
import { useLayoutEffect } from 'react';
import SubTxt from '../../components/sub-txt/sub-txt.component';
// import SubProcedurePhotos from '../../components/sub-procedure-photos/sub-procedure-photos.component';
import SubFooter from '../../components/sub-footer/sub-footer.component';
import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import './sub-procedure.styles.scss';
import { getProcedures } from '../../utils/apiService';
import SubProcedureForm from '../../components/sub-procedure-form/sub-procedure-form.component';
import SubProcedureScroll from '../../components/sub-procedure-scroll/sub-procedure-scroll.component';
import SubProcedureFormV2 from '../../components/sub-procedure-form-v2/sub-procedure-form-v2.component';
import HomeLink from '../../components/home-link/home-link.component';
import SubProcedureReference from '../../components/sub-procedure-reference/sub-procedure-reference.component';
const SubProcedure = () => {
    
    const { name } = useParams();
    const [data, setData] = useState(null);
    useEffect(() => {
        window.scrollTo(0, 0);
        const fetchData = async () => {
            const response = await getProcedures({ name });
            setData(response); 
        };
        fetchData();
    }, [name]);  
    if (!data) {
        console.log('data is not valid');
        // you may return here or render some fallback UI
        return null; // or <div>Data is not valid</div> or any other fallback UI
    }
    if(!data.optionsForm){
        console.log('data.optionsForm is not valid');
        // you may return here or render some fallback UI
        return null; // or <div>Data is not valid</div> or any other fallback UI
    }
    if(!data.beforeAndAfter){
        console.log('data.beforeAndAfter is not valid');
        // you may return here or render some fallback UI
        return null; // or <div>Data is not valid</div> or any other fallback UI
    }
    if(!data.optionsContent){
        console.log('data.optionsContent is not valid');
        // you may return here or render some fallback UI
        return null; // or <div>Data is not valid</div> or any other fallback UI
    }
    if(!data.sideEffect){
        console.log('data.sideEffect is not valid');
        // you may return here or render some fallback UI
        return null; // or <div>Data is not valid</div> or any other fallback UI
    }
    return (
    <div className='home-container'>
        <div className='sub-content'>
            <div className='.sub-procedure-option-form-container'>
                <SubTxt title={'Procedure options'} text={data.optionsContent}/>
                <SubProcedureForm data={data.optionsForm} />  
            </div>
            <div className='sub-procedure-side-effect'>
                <SubTxt title={'Potential Side Effects'} text={data.sideEffect}/>
            </div>
            <div className='sub-procedure-scroll-container'>
                <SubTxt title={'Before and After'} text={data.beforeAndAfter}/>
                <SubProcedureScroll/>
                <div className='sub-link'>
                   <HomeLink title={'View More Post'} href = "procedure/facial-rejuvenation"/>
                </div> 
            </div>
            <div className='sub-procedure-form-ver'>
                  <div className='sub-title'>
                       Alternative treatments
                  </div>
                  <SubProcedureFormV2/>
            </div>
            <div className='sub-procedure-reference'>
                  <div className='sub-title'>
                     References and resources
                  </div>
                <SubProcedureReference/>
            </div>
            
            
           
        </div>
        
        <Footer />
      
    </div>
        
    )
}

export default SubProcedure;

